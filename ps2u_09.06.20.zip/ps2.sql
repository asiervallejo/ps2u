-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-06-2020 a las 13:05:29
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ps2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `desarrolladores`
--

CREATE TABLE `desarrolladores` (
  `id_desarrollador` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `desarrolladores`
--

INSERT INTO `desarrolladores` (`id_desarrollador`, `nombre`) VALUES
(1, 'Clover Studio'),
(5, 'Level-5'),
(3, 'Polyphony Digital'),
(2, 'Sony'),
(4, 'Treyarch');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estrellas`
--

CREATE TABLE `estrellas` (
  `id` int(11) NOT NULL,
  `ratedIndex` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estrellas`
--

INSERT INTO `estrellas` (`id`, `ratedIndex`) VALUES
(1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `generos`
--

CREATE TABLE `generos` (
  `id_genero` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `generos`
--

INSERT INTO `generos` (`id_genero`, `nombre`) VALUES
(6, 'Action'),
(2, 'Action RPG'),
(3, 'Driving'),
(4, 'Plataformer'),
(1, 'RPG'),
(7, 'Shooter'),
(8, 'Sports'),
(5, 'Survival Horror');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes`
--

CREATE TABLE `imagenes` (
  `id_imagen` int(11) NOT NULL,
  `url_imagen` varchar(200) DEFAULT NULL,
  `id_juego` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `imagenes`
--

INSERT INTO `imagenes` (`id_imagen`, `url_imagen`, `id_juego`) VALUES
(62, 'https://mediamaster.vandal.net/m/3624/2006220185510_8.jpg', 1),
(67, 'https://mediamaster.vandal.net/m/3624/2006220185510_2.jpg', 1),
(68, 'https://mediamaster.vandal.net/m/3624/2006220185510_3.jpg', 1),
(69, 'https://mediamaster.vandal.net/m/3624/2006220185510_4.jpg', 1),
(70, 'https://mediamaster.vandal.net/m/3624/2006220185510_5.jpg', 1),
(71, 'https://mediamaster.vandal.net/m/3624/2006220185510_6.jpg', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos`
--

CREATE TABLE `juegos` (
  `id_juego` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `genero` int(11) DEFAULT NULL,
  `desarrollador` int(11) DEFAULT NULL,
  `front_cover` varchar(100) NOT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `juegos`
--

INSERT INTO `juegos` (`id_juego`, `titulo`, `genero`, `desarrollador`, `front_cover`, `fecha`, `descripcion`) VALUES
(1, 'Okami', 2, 1, '81sOcu7QoCLSY879.jpg', '2006-04-20', 'The game is set in a Nippon (Japan) based on Japanese folklore, and begins with a flashback to events 100 years prior to the game\'s present; the narrator describes how Shiranui, a pure white wolf, and Nagi, a swordsman, together fought the eight-headed demon Orochi to save Kamiki Village and the maiden Nami, Nagi\'s beloved. Shiranui and Nagi are unable to defeat Orochi, but manage to seal the demon away.'),
(2, 'Dark Cloud', 2, 5, '51CV79TSQNLSY445.jpg', NULL, NULL),
(3, 'Dark Chronicle', 2, 5, '51F94XVT13LSY445.jpg', NULL, NULL),
(17, 'Gran Turismo 4', 3, 3, '', '2002-02-02', 'yujkhjkh'),
(18, 'Gran Turismo 3', 3, 3, '', '2000-02-02', 'gggg'),
(31, 'Viewtiful Joe', 6, 1, '', '2004-10-22', 'Viewtiful Joe is a side scrolling beat \'em up video game developed by Team Viewtiful for the GameCube. It was originally released in 2003 as a part of the Capcom Five under director Hideki Kamiya and producer Atsushi Inaba. The game was later ported to the PlayStation 2 by the same design team under the name Clover Studio, subtitled in Japan Aratanaru Kibō (Japanese: 新たなる希望, lit. \"A New Hope\"). The game\'s story concerns Joe, an avid movie-goer whose girlfriend Silvia is kidnapped during a film starring Joe\'s favorite superhero, Captain Blue. Joe is shortly thereafter thrust into Movieland, where Silvia is taken by the villainous group known as Jadow. After accepting a special V-Watch from Captain Blue, Joe transforms into the tokusatsu-style persona \"Viewtiful Joe\" and sets out to rescue her.'),
(35, 'Tourist Trophy', 3, 3, 'c5be9cc51ee4f28d96a42072e54fb357.jpg', '2006-06-02', 'Tourist Trophy: The Real Riding Simulator (ツーリスト・トロフィー, Tsūrisuto Torofī) is a 2006 motorcycle racing video game. It was designed by Polyphony Digital, the same team behind the popular Gran Turismo auto racing series. Tourist Trophy is one of only four titles for the PlayStation 2 that is capable of 1080i output, another being Gran Turismo 4, the game engine of which is heavily used in Tourist Trophy.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos_region`
--

CREATE TABLE `juegos_region` (
  `id_juego_region` int(11) NOT NULL,
  `id_juego` int(11) NOT NULL,
  `id_region` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `juegos_region`
--

INSERT INTO `juegos_region` (`id_juego_region`, `id_juego`, `id_region`) VALUES
(8, 1, NULL),
(9, 1, 2),
(10, 1, 3),
(7, 2, 1),
(6, 2, 2),
(4, 2, 3),
(3, 3, 1),
(2, 3, 2),
(1, 3, 3),
(14, 17, 2),
(13, 17, 3),
(17, 18, 1),
(16, 18, 2),
(15, 18, 3),
(46, 31, 1),
(47, 31, 2),
(48, 31, 3),
(58, 35, 1),
(59, 35, 2),
(60, 35, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `region`
--

CREATE TABLE `region` (
  `id_region` int(11) NOT NULL,
  `nombre` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `region`
--

INSERT INTO `region` (`id_region`, `nombre`) VALUES
(1, 'NTSC-J'),
(2, 'NTSC-U'),
(3, 'PAL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_user` int(11) NOT NULL,
  `nick` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_user`, `nick`, `email`, `password`) VALUES
(1, 'dextroyer', 'realdextroyer@gmail.com', '666fade666'),
(2, 'darknios', 'darknios@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valoracion`
--

CREATE TABLE `valoracion` (
  `id_valoracion` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_juego` int(11) NOT NULL,
  `nota` float NOT NULL,
  `comentario` text NOT NULL,
  `juego_pasado` tinyint(1) NOT NULL,
  `horas_juego` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `valoracion`
--

INSERT INTO `valoracion` (`id_valoracion`, `id_user`, `id_juego`, `nota`, `comentario`, `juego_pasado`, `horas_juego`) VALUES
(1, 1, 1, 9.3, 'Un must have de toda la vida', 0, 12),
(2, 2, 1, 8.5, '', 1, 45);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `desarrolladores`
--
ALTER TABLE `desarrolladores`
  ADD PRIMARY KEY (`id_desarrollador`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `estrellas`
--
ALTER TABLE `estrellas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `generos`
--
ALTER TABLE `generos`
  ADD PRIMARY KEY (`id_genero`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD PRIMARY KEY (`id_imagen`),
  ADD KEY `id_juego` (`id_juego`);

--
-- Indices de la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD PRIMARY KEY (`id_juego`),
  ADD KEY `genero` (`genero`),
  ADD KEY `desarrollador` (`desarrollador`);

--
-- Indices de la tabla `juegos_region`
--
ALTER TABLE `juegos_region`
  ADD PRIMARY KEY (`id_juego_region`),
  ADD UNIQUE KEY `id_juego_2` (`id_juego`,`id_region`),
  ADD KEY `id_juego` (`id_juego`),
  ADD KEY `id_region` (`id_region`);

--
-- Indices de la tabla `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`id_region`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `nick` (`nick`,`email`);

--
-- Indices de la tabla `valoracion`
--
ALTER TABLE `valoracion`
  ADD PRIMARY KEY (`id_valoracion`),
  ADD UNIQUE KEY `id_user_2` (`id_user`,`id_juego`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_juego` (`id_juego`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `desarrolladores`
--
ALTER TABLE `desarrolladores`
  MODIFY `id_desarrollador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `estrellas`
--
ALTER TABLE `estrellas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `generos`
--
ALTER TABLE `generos`
  MODIFY `id_genero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `imagenes`
--
ALTER TABLE `imagenes`
  MODIFY `id_imagen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT de la tabla `juegos`
--
ALTER TABLE `juegos`
  MODIFY `id_juego` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `juegos_region`
--
ALTER TABLE `juegos_region`
  MODIFY `id_juego_region` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `region`
--
ALTER TABLE `region`
  MODIFY `id_region` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `valoracion`
--
ALTER TABLE `valoracion`
  MODIFY `id_valoracion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD CONSTRAINT `imagenes_ibfk_1` FOREIGN KEY (`id_juego`) REFERENCES `juegos` (`id_juego`);

--
-- Filtros para la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD CONSTRAINT `juegos_ibfk_1` FOREIGN KEY (`genero`) REFERENCES `generos` (`id_genero`),
  ADD CONSTRAINT `juegos_ibfk_2` FOREIGN KEY (`desarrollador`) REFERENCES `desarrolladores` (`id_desarrollador`);

--
-- Filtros para la tabla `juegos_region`
--
ALTER TABLE `juegos_region`
  ADD CONSTRAINT `juegos_region_ibfk_2` FOREIGN KEY (`id_region`) REFERENCES `region` (`id_region`),
  ADD CONSTRAINT `juegos_region_ibfk_3` FOREIGN KEY (`id_juego`) REFERENCES `juegos` (`id_juego`) ON DELETE CASCADE;

--
-- Filtros para la tabla `valoracion`
--
ALTER TABLE `valoracion`
  ADD CONSTRAINT `valoracion_ibfk_1` FOREIGN KEY (`id_juego`) REFERENCES `juegos` (`id_juego`),
  ADD CONSTRAINT `valoracion_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `usuarios` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
